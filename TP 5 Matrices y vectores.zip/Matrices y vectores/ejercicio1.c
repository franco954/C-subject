

#include <stdio.h>


int main(int argc, char const *argv[])
{
    
    int miArray[5]={10,100,94,84,11};
    
    return 0;
}
